CREATE DATABASE IF NOT EXISTS jm_paddy CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE jm_paddy;

DROP TABLE IF EXISTS bills;
DROP TABLE IF EXISTS farmers;
DROP TABLE IF EXISTS district_settings;
DROP TABLE IF EXISTS users;

CREATE TABLE users (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 username VARCHAR(50) NOT NULL UNIQUE,
 full_name VARCHAR(100) NOT NULL,
 password_hash VARCHAR(255) NOT NULL,
 active TINYINT(1) NOT NULL DEFAULT 1,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE district_settings (
 district VARCHAR(50) PRIMARY KEY,
 sack_weight_kg DECIMAL(10,2) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE farmers (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(120) NOT NULL,
 phone VARCHAR(30) NULL,
 address TEXT NULL,
 district VARCHAR(50) NOT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_farmer_name(name),
 INDEX idx_farmer_phone(phone)
) ENGINE=InnoDB;

CREATE TABLE bills (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 bill_number VARCHAR(30) NOT NULL UNIQUE,
 farmer_id INT UNSIGNED NOT NULL,
 bill_date DATE NOT NULL,
 paddy_type VARCHAR(50) NOT NULL,
 gross_weight_kg DECIMAL(12,2) NOT NULL,
 sack_weight_kg DECIMAL(10,2) NOT NULL,
 sack_count INT NOT NULL,
 net_weight_kg DECIMAL(12,2) NOT NULL,
 price_per_kg DECIMAL(12,2) NOT NULL,
 total_amount DECIMAL(14,2) NOT NULL,
 status ENUM('Paid','Due') NOT NULL DEFAULT 'Paid',
 created_by INT UNSIGNED NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_bill_farmer FOREIGN KEY (farmer_id) REFERENCES farmers(id) ON UPDATE CASCADE ON DELETE RESTRICT,
 CONSTRAINT fk_bill_user FOREIGN KEY (created_by) REFERENCES users(id) ON UPDATE CASCADE ON DELETE SET NULL,
 INDEX idx_bill_date(bill_date),
 INDEX idx_bill_farmer(farmer_id)
) ENGINE=InnoDB;

INSERT INTO district_settings(district,sack_weight_kg) VALUES
('Vavuniya',72),('Mullaitivu',73),('Mannar',73),('Kilinochchi',73),('Jaffna',73);

-- Demo password is: admin123
INSERT INTO users(username,full_name,password_hash) VALUES
('admin','JM PADDY Administrator','$2y$12$DHLzBhs0aPlV5ZGHK7ic1ucWItlXviHSDEh3HMVX78m32SptfZuz.');

INSERT INTO farmers(name,phone,address,district) VALUES
('K. Sivakumar','077 123 4567','Puthukkudimanai, Vavuniya','Vavuniya'),
('W.A. Perera','071 987 6543','Mannar Road, Mannar','Mannar'),
('A. Niroshan','076 222 3333','Nedunkeni, Vavuniya','Vavuniya');

INSERT INTO bills(bill_number,farmer_id,bill_date,paddy_type,gross_weight_kg,sack_weight_kg,sack_count,net_weight_kg,price_per_kg,total_amount,status,created_by) VALUES
('#B1042',1,'2026-08-29','Nadu',620,72,8,44,120,74400,'Paid',1),
('#B1041',2,'2026-08-29','Samba',510,73,6,72,120,61200,'Paid',1),
('#B1040',3,'2026-08-28','Nadu',430,72,5,70,115,49450,'Paid',1);
