function calculateBill(){
  const gross=parseFloat(document.getElementById('gross_weight')?.value||0);
  const sack=parseFloat(document.getElementById('sack_weight')?.value||0);
  const price=parseFloat(document.getElementById('price_per_kg')?.value||0);
  const sacks=sack>0?Math.floor(gross/sack):0;
  const sackTotal=sacks*sack;
  const net=Math.max(gross-sackTotal,0);
  const total=gross*price;
  const set=(id,val)=>{const el=document.getElementById(id);if(el)el.textContent=val;};
  set('preview_sacks', sacks.toString());set('preview_sack_total', `${sackTotal.toFixed(2)} kg`);set('preview_net', `${net.toFixed(2)} kg`);set('preview_total', `Rs. ${total.toLocaleString('en-LK',{minimumFractionDigits:2,maximumFractionDigits:2})}`);
}
function setSackWeight(){
 const select=document.getElementById('district'); const data=window.districtWeights||{}; const input=document.getElementById('sack_weight'); if(select&&input&&data[select.value]) input.value=data[select.value]; calculateBill();
}
function printBill(){window.print();}
function shareWhatsApp(text){window.open('https://wa.me/?text='+encodeURIComponent(text),'_blank','noopener');}
document.addEventListener('DOMContentLoaded',()=>{['gross_weight','sack_weight','price_per_kg'].forEach(id=>document.getElementById(id)?.addEventListener('input',calculateBill));document.getElementById('district')?.addEventListener('change',setSackWeight);calculateBill();});
