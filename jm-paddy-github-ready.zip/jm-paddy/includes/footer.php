</section>
<footer class="footer"><?= APP_NAME ?> · Digital paddy purchasing & farmer billing</footer>
</main></div>
<script src="assets/js/app.js"></script>
</body></html>
