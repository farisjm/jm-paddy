<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/helpers.php';
$pageTitle = $pageTitle ?? APP_NAME;
$user = current_user();
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($pageTitle) ?> · <?= APP_NAME ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/css/app.css">
</head>
<body>
<div class="app-shell">
<aside class="sidebar" id="sidebar">
  <div class="brand"><div class="brand-mark">JP</div><div><strong>JM PADDY</strong><span>Farmer & Billing</span></div></div>
  <nav>
    <a href="dashboard.php" class="nav-link">Dashboard</a>
    <a href="farmers.php" class="nav-link">Farmers</a>
    <a href="bills.php" class="nav-link">Bills</a>
    <a href="bill_create.php" class="nav-link nav-primary">+ New Bill</a>
    <a href="reports.php" class="nav-link">Reports</a>
    <a href="settings.php" class="nav-link">Settings</a>
  </nav>
  <div class="sidebar-footer"><span><?= e($user['full_name'] ?? 'Staff') ?></span><a href="logout.php">Logout</a></div>
</aside>
<main class="main-content">
<header class="topbar"><button class="menu-btn" type="button" onclick="document.getElementById('sidebar').classList.toggle('open')">☰</button><div><div class="eyebrow">Paddy management</div><h1><?= e($pageTitle) ?></h1></div><div class="top-user"><?= e($user['username'] ?? '') ?></div></header>
<?php if ($msg = flash('success')): ?><div class="alert success"><?= e($msg) ?></div><?php endif; ?>
<?php if ($msg = flash('error')): ?><div class="alert error"><?= e($msg) ?></div><?php endif; ?>
<section class="page-body">
