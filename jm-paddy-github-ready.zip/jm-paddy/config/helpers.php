<?php
declare(strict_types=1);

function e(?string $value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function money(float|int $value): string {
    return CURRENCY . ' ' . number_format((float)$value, 2);
}

function redirect(string $url): never {
    header('Location: ' . $url);
    exit;
}

function flash(string $key, ?string $value = null): ?string {
    if ($value !== null) {
        $_SESSION['_flash'][$key] = $value;
        return null;
    }
    $msg = $_SESSION['_flash'][$key] ?? null;
    unset($_SESSION['_flash'][$key]);
    return $msg;
}

function require_login(): void {
    if (empty($_SESSION['user'])) {
        redirect('login.php');
    }
}

function current_user(): ?array {
    return $_SESSION['user'] ?? null;
}

function csrf_token(): string {
    if (empty($_SESSION['_csrf'])) {
        $_SESSION['_csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['_csrf'];
}

function verify_csrf(?string $token): void {
    if (!hash_equals($_SESSION['_csrf'] ?? '', (string)$token)) {
        http_response_code(419);
        exit('Invalid CSRF token.');
    }
}

function districts(PDO $pdo): array {
    return $pdo->query('SELECT district, sack_weight_kg FROM district_settings ORDER BY district')->fetchAll();
}

function next_bill_number(PDO $pdo): string {
    $stmt = $pdo->query('SELECT bill_number FROM bills ORDER BY id DESC LIMIT 1');
    $last = $stmt->fetchColumn();
    if (!$last) return '#B1001';
    $n = (int)preg_replace('/\D+/', '', (string)$last) + 1;
    return '#B' . $n;
}
